-- Bulldoze behavior -- Project Zomboid B42.21.
-- Remote players return before OnPlayerUpdate in IsoPlayer.updateInternal2.
-- Dedicated MP therefore uses the server OnTick loop; SP keeps OnPlayerUpdate.
if isClient() then return end

local RADIUS = 1.5
local CONE_COSINE = math.cos(math.rad(45))
local CHECK_INTERVAL_MS = 50
local LOG_INTERVAL_MS = 10000
local nextCheck = 0
local nextMissingTraitLog = 0
local diagnostics = setmetatable({}, { __mode = "k" })
local prefix = "[CREATINE][Bulldoze][server/SP] "

local function updatePlayer(player, now)
    if not player or player:isDead() then return end
    if not CREATINE_BulldozeTraitType then
        if now >= nextMissingTraitLog then
            print(prefix .. "Waiting for Bulldoze trait registration")
            nextMissingTraitLog = now + LOG_INTERVAL_MS
        end
        return
    end
    if not player:hasTrait(CREATINE_BulldozeTraitType) then
        diagnostics[player] = nil
        return
    end

    local state = diagnostics[player]
    if not state then
        state = { nextLog = 0, attempted = 0, killed = 0 }
        diagnostics[player] = state
        print(prefix .. "Trait detected: player=" .. tostring(player:getUsername()))
    end
    local running = player:isRunning()
    local nearby, targets = 0, 0
    if running then
        local cell = getCell()
        local facingX = player:getForwardDirectionX()
        local facingY = player:getForwardDirectionY()
        if cell then
            local zombies = cell:getZombieList()
            local px, py, pz = player:getX(), player:getY(), player:getZ()
            -- Reverse iteration: server die() removes the zombie from the cell.
            for i = zombies:size() - 1, 0, -1 do
                local zombie = zombies:get(i)
                if zombie and not zombie:isDead() and zombie:getZ() == pz then
                    local dx = zombie:getX() - px
                    local dy = zombie:getY() - py
                    local distance = math.sqrt(dx * dx + dy * dy)
                    if distance > 0 and distance <= RADIUS then
                        nearby = nearby + 1
                        local dot = facingX * (dx / distance) + facingY * (dy / distance)
                        if dot >= CONE_COSINE then
                            targets = targets + 1
                            state.attempted = state.attempted + 1
                            zombie:Kill(player)
                            -- Kill sets health/onKilled; die finalizes the corpse.
                            -- IsoZombie.onDied sends the server's character-death packet.
                            if isServer() then zombie:die() end
                            if zombie:isDead() then state.killed = state.killed + 1 end
                        end
                    end
                end
            end
        end
    end
    if now >= state.nextLog then
        print(prefix .. "player=" .. tostring(player:getUsername()) ..
            " running=" .. tostring(running) ..
            " nearby=" .. nearby .. " coneTargets=" .. targets ..
            " attemptsSinceLog=" .. state.attempted .. " killedSinceLog=" .. state.killed)
        state.nextLog = now + LOG_INTERVAL_MS
        state.attempted, state.killed = 0, 0
    end
end

if isServer() then
    Events.OnTick.Add(function()
        local now = getTimestampMs()
        if now < nextCheck then return end
        nextCheck = now + CHECK_INTERVAL_MS
        local players = getOnlinePlayers()
        for i = 0, players:size() - 1 do
            updatePlayer(players:get(i), now)
        end
    end)
    print(prefix .. "Registered server OnTick handler (50ms checks)")
else
    Events.OnPlayerUpdate.Add(function(player)
        updatePlayer(player, getTimestampMs())
    end)
    print(prefix .. "Registered single-player OnPlayerUpdate handler")
end
