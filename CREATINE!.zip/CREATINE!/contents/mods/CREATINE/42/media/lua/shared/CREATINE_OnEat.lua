-- Diagnostic-only consumption bridge for CREATINE! / Build 42.21.
-- This does not treat ordinary Junkiez shakes as a CREATINE dose.
local accepted = {
    ["CREATINE.Creatine"] = true,
    ["CREATINE.CreatineSmoothie"] = true,
    ["JunkiezMoreSupplements.JunkiezShake"] = true,
    ["JunkiezMoreSupplements.JunkiezBlendedShake"] = true,
}

local function side()
    if isClient() then return 'client' end
    if isServer() then return 'server' end
    return 'SP'
end

local function inspectScript()
    if not ScriptManager or not ScriptManager.instance then return end
    for _, fullType in ipairs({
        'CREATINE.Creatine', 'CREATINE.CreatineSmoothie',
        'JunkiezMoreSupplements.JunkiezShake',
        'JunkiezMoreSupplements.JunkiezBlendedShake',
    }) do
        local ok, item = pcall(function() return ScriptManager.instance:getItem(fullType) end)
        if ok and item then
            print('[CREATINE][' .. side() .. '][probe] script=' .. fullType .. ' present')
        else
            print('[CREATINE][' .. side() .. '][probe] script absent=' .. fullType)
        end
    end
end

local function listIngredients(item)
    local ok, extras = pcall(function() return item:getExtraItems() end)
    if not ok or not extras then return '<unavailable>' end
    local parts = {}
    for i = 0, extras:size() - 1 do
        parts[#parts + 1] = tostring(extras:get(i))
    end
    return table.concat(parts, ',')
end

function CREATINE_OnEat(item, character, percentage)
    if not item or not character then
        print('[CREATINE][' .. side() .. '] OnEat missing item or character')
        return
    end
    local fullType = item:getFullType()
    local consumed = tonumber(percentage)
    print('[CREATINE][' .. side() .. '] OnEat item=' .. tostring(fullType) ..
        ' fraction=' .. tostring(percentage) .. ' extras=' .. listIngredients(item))
    if not accepted[fullType] then
        print('[CREATINE][' .. side() .. '] Skipping non-CREATINE product')
        return
    end
    if fullType == 'JunkiezMoreSupplements.JunkiezShake' or
       fullType == 'JunkiezMoreSupplements.JunkiezBlendedShake' then
        local hasCreatine = false
        local ok, extras = pcall(function() return item:getExtraItems() end)
        if ok and extras then
            for i = 0, extras:size() - 1 do
                local ingredient = tostring(extras:get(i))
                if ingredient == 'CREATINE.Creatine' then
                    hasCreatine = true
                    break
                end
            end
        end
        if not hasCreatine then
            print('[CREATINE][' .. side() .. '] Junkiez shake has no CREATINE.Creatine ingredient; no dose')
            return
        end
        print('[CREATINE][' .. side() .. '] Confirmed CREATINE.Creatine in Junkiez shake')
    end
    if not consumed or consumed <= 0 then
        print('[CREATINE][' .. side() .. '] Skipping zero/unknown consumption')
        return
    end
    if isClient() then
        print('[CREATINE][client] Sending dose notice for ' .. fullType)
        sendClientCommand('CREATINE', 'dose', { itemType = fullType })
    elseif C_Master_RecordDose then
        C_Master_RecordDose(character)
    else
        print('[CREATINE][' .. side() .. '] C_Master_RecordDose unavailable')
    end
end

print('[CREATINE][' .. side() .. '] OnEat Lua loaded; callback=' .. tostring(CREATINE_OnEat))
-- Item scripts are installed at runtime; no Junkiez files are included or modified.
-- Preserve Junkiez's original shake callback, which handles its bottle return.
local originalJunkiezShakeCallback = nil
local function patchJunkiezCallbacks()
    if not ScriptManager or not ScriptManager.instance then return end
    local entries = {
        'JunkiezMoreSupplements.JunkiezShake',
        'JunkiezMoreSupplements.JunkiezBlendedShake',
    }
    for _, fullType in ipairs(entries) do
        local ok, script = pcall(function() return ScriptManager.instance:getItem(fullType) end)
        if ok and script then
            local old = fullType == 'JunkiezMoreSupplements.JunkiezShake'
                and 'OnEat_JunkiezProteinShake' or nil
            if fullType == 'JunkiezMoreSupplements.JunkiezShake' and
               old and old ~= '' and old ~= 'CREATINE_JunkiezOnEat' then
                originalJunkiezShakeCallback = old
            end
            if old ~= 'CREATINE_JunkiezOnEat' then
                script:DoParam('OnEat', 'CREATINE_JunkiezOnEat')
            end
            print('[CREATINE][' .. side() .. '] Installed ingredient-aware callback on ' .. fullType ..
                ' original=' .. tostring(old))
        end
    end
end

function CREATINE_JunkiezOnEat(item, character, percentage)
    -- Junkiez' ordinary shake returns its empty bottle through this callback.
    -- Invoke that callback unchanged even for shakes without creatine.
    if item and item:getFullType() == 'JunkiezMoreSupplements.JunkiezShake' then
        local name = originalJunkiezShakeCallback
        if not name or name == '' then name = 'OnEat_JunkiezProteinShake' end
        local callback = _G[name]
        if type(callback) == 'function' then
            callback(item, character, percentage)
        else
            print('[CREATINE][' .. side() .. '] WARNING: Junkiez original OnEat callback unavailable: ' .. tostring(name))
        end
    end
    CREATINE_OnEat(item, character, percentage)
end

-- Build 42.21 Item script definitions support DoParam('OnEat', name),
-- not getOnEat()/setOnEat() (those belong to inventory Food instances).
-- Register after item scripts load; a second attempt covers MP initialization.
patchJunkiezCallbacks()
if Events.OnGameStart then
    Events.OnGameStart.Add(function() patchJunkiezCallbacks(); inspectScript() end)
end
if Events.OnServerStarted then Events.OnServerStarted.Add(patchJunkiezCallbacks) end

