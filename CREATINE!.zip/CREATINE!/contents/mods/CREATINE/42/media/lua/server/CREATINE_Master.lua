-- CREATINE loading and milestone system -- Project Zomboid 42.21

MilestoneSystem = MilestoneSystem or {}
MilestoneSystem.DAYS_TO_LOAD = 7
MilestoneSystem.Packs = {
    { name = "Bully",          weight = 85,  fitness = 5,  strength = 5 },
    { name = "Tactician",      weight = 95,  fitness = 6,  strength = 7 },
    { name = "Berserker",      weight = 110, fitness = 8,  strength = 9 },
    { name = "UnyieldingWill", weight = 130, fitness = 10, strength = 10 },
}

MilestoneSystem.SpeechGain = {
    Bully          = "I could punch holes in the wall!",
    Tactician      = "I can shoot the peter off a skeeter at a hundred meters.",
    Berserker      = "WHERE ARE THEY?",
    UnyieldingWill = "I pity them no longer.",
}
MilestoneSystem.SpeechLoss = "Feel... so... weak..."

local function bundles()
    return {
        Bully = {
            CharacterTrait.NUTRITIONIST,
            CharacterTrait.THICK_SKINNED,
            CharacterTrait.RESILIENT,
        },
        Tactician = {
            CharacterTrait.GRACEFUL,
            CharacterTrait.GYMNAST,
            CharacterTrait.HUNTER,
        },
        Berserker = {
            CharacterTrait.ADRENALINE_JUNKIE,
            CharacterTrait.ATHLETIC,
            CharacterTrait.AXEMAN,
        },
        UnyieldingWill = {
            CREATINE_RageTraitType,
            CREATINE_BulldozeTraitType,
        },
    }
end

local function traitKey(traitType)
    return tostring(traitType)
end

-- B42.21 MP: player:getModData() writes can be visible during play but did not
-- survive restart in the user's dedicated-server test. The world Global ModData
-- ledger is therefore canonical on MP servers. It is saved with the world.
-- The username is the stable account key available to this code; this means
-- progression is account-scoped, not automatically reset on a new character.
local CREATINE_LEDGER_KEY = 'CREATINE_DoseLedger_B42'
local CREATINE_ledgerLogged = {}

-- PZ's Kahlua environment does not reliably provide Lua's next() global.
-- Test for populated tables using pairs(), which is supported by B42.21.
local function tableHasEntries(value)
    if type(value) ~= 'table' then return false end
    for _ in pairs(value) do
        return true
    end
    return false
end

local function hasProgress(data)
    return type(data) == 'table' and (
        data.DoseDayCount ~= nil or data.CreatineLoaded ~= nil or
        tableHasEntries(data.DoseDays) or
        tableHasEntries(data.ActiveMilestones) or
        tableHasEntries(data.GrantedTraits) or
        data.StrainDay ~= nil or data.StrainedToday ~= nil)
end

local function ensureFields(data)
    data.DoseDays = type(data.DoseDays) == 'table' and data.DoseDays or {}
    data.ActiveMilestones = type(data.ActiveMilestones) == 'table' and data.ActiveMilestones or {}
    data.GrantedTraits = type(data.GrantedTraits) == 'table' and data.GrantedTraits or {}
    return data
end

local function dataFor(player)
    local root = player:getModData()
    if isServer() then
        -- Never mutate client-provided history into another user's record.
        local username = player:getUsername()
        if not username or username == '' then
            print('[CREATINE][server][persistence-warning] missing username; using transient character data')
            root.CREATINE = ensureFields(root.CREATINE or {})
            return root.CREATINE
        end
        local ledger = ModData.getOrCreate(CREATINE_LEDGER_KEY)
        local saved = ledger[username]
        if type(saved) ~= 'table' then
            -- One-time migration for characters with any already-existing
            -- progression; new users begin with a fresh ledger record.
            saved = hasProgress(root.CREATINE) and root.CREATINE or {}
            ledger[username] = saved
            print('[CREATINE][server][ledger-init] player=' .. tostring(username) ..
                ' migratedCharacterData=' .. tostring(hasProgress(root.CREATINE)))
        elseif not CREATINE_ledgerLogged[username] then
            print('[CREATINE][server][ledger-restore] player=' .. tostring(username) ..
                ' savedCount=' .. tostring(saved.DoseDayCount) ..
                ' loaded=' .. tostring(saved.CreatineLoaded == true))
        end
        CREATINE_ledgerLogged[username] = true
        ensureFields(saved)
        -- Expose the canonical record to existing milestone/trait code.
        -- No client-to-server overwrite occurs when a player reconnects.
        root.CREATINE = saved
        return saved
    end
    root.CREATINE = ensureFields(root.CREATINE or {})
    return root.CREATINE
end

local function addBundleTrait(player, data, traitType)
    if not traitType or player:hasTrait(traitType) then return end
    player:getCharacterTraits():add(traitType)
    data.GrantedTraits[traitKey(traitType)] = true
end

local function activeMilestoneNeeds(data, traitType)
    local allBundles = bundles()
    for milestoneName in pairs(data.ActiveMilestones) do
        for _, neededType in ipairs(allBundles[milestoneName] or {}) do
            if neededType == traitType then return true end
        end
    end
    return false
end

local function removeBundleTrait(player, data, traitType)
    local key = traitKey(traitType)
    if not data.GrantedTraits[key] or activeMilestoneNeeds(data, traitType) then return end
    if player:hasTrait(traitType) then player:getCharacterTraits():remove(traitType) end
    data.GrantedTraits[key] = nil
end

local function suppressWeightTraits(player, data)
    if not data.CreatineLoaded then return end
    local traits = player:getCharacterTraits()
    if player:hasTrait(CharacterTrait.OBESE) then traits:remove(CharacterTrait.OBESE) end
    if player:hasTrait(CharacterTrait.OVERWEIGHT) then traits:remove(CharacterTrait.OVERWEIGHT) end
end

local function grantMilestone(player, data, milestoneName)
    if data.ActiveMilestones[milestoneName] then
        for _, traitType in ipairs(bundles()[milestoneName] or {}) do
            addBundleTrait(player, data, traitType)
        end
        return
    end
    data.ActiveMilestones[milestoneName] = true
    for _, traitType in ipairs(bundles()[milestoneName] or {}) do
        addBundleTrait(player, data, traitType)
    end
    local line = MilestoneSystem.SpeechGain[milestoneName]
    if line then player:Say(line) end
end

local function removeMilestone(player, data, milestoneName)
    if not data.ActiveMilestones[milestoneName] then return false end
    data.ActiveMilestones[milestoneName] = nil
    for _, traitType in ipairs(bundles()[milestoneName] or {}) do
        removeBundleTrait(player, data, traitType)
    end
    return true
end

-- Read actual vanilla exercise regularity; at least three distinct types must each reach 25.
-- Physical labor/stiffness does not count.
-- The diagnostic verified this registry and getRegularity() on B42.21 MP.
-- No Java HashMap iteration: Kahlua cannot safely call keySet():iterator().
local CREATINE_lastRegularityLog = {}
local function CREATINE_ReadWorkoutRegularity(player)
    local workout = player and player:getFitness()
    local exerciseTypes = FitnessExercises and FitnessExercises.exercisesType
    if not workout or type(exerciseTypes) ~= 'table' then
        return nil, nil, false
    end

    local qualifiedCount, observedCount = 0, 0
    local qualifiedExercises = {}
    for exercise in pairs(exerciseTypes) do
        if type(exercise) == 'string' then
            local regularity = tonumber(workout:getRegularity(exercise)) or 0
            if regularity > 0 then observedCount = observedCount + 1 end
            if regularity >= 25 then
                qualifiedCount = qualifiedCount + 1
                qualifiedExercises[#qualifiedExercises + 1] = exercise
            end
        end
    end
    table.sort(qualifiedExercises)
    return qualifiedCount, observedCount, qualifiedCount >= 3, table.concat(qualifiedExercises, ',')
end

function C_Master_EvaluateMilestones(player)
    if not player or player:isDead() then return end
    local data = dataFor(player)
    local nutrition = player:getNutrition()
    local weight = nutrition and nutrition:getWeight() or 0
    local fitness = player:getPerkLevel(Perks.Fitness)
    local strength = player:getPerkLevel(Perks.Strength)
    local lostAny = false
    local qualifiedCount, observedCount, regularityQualified, qualifiedExercises = CREATINE_ReadWorkoutRegularity(player)
    -- A missing registry must never issue a new award. Existing awards remain
    -- subject only to the original loading, weight and skill maintenance gates.
    local username = tostring(player:getUsername())
    local summary = qualifiedCount and
        (tostring(qualifiedCount) .. '/' .. tostring(observedCount) .. '/' .. tostring(regularityQualified) .. '/' .. qualifiedExercises) or
        'unavailable'
    if CREATINE_lastRegularityLog[username] ~= summary then
        CREATINE_lastRegularityLog[username] = summary
        print('[CREATINE][regularity-gate][server/SP] player=' .. username ..
            ' exercisesAt25=' .. tostring(qualifiedCount) ..
            ' exercisesAboveZero=' .. tostring(observedCount) ..
            ' qualifyingTypes=[' .. tostring(qualifiedExercises) .. ']' ..
            ' qualified=' .. tostring(regularityQualified))
    end

    data.CreatineWeight = weight
    -- Attainment now requires >=3 distinct exercise types at >=25 regularity each.
    -- No mean is computed: experimenting with extra workouts cannot reduce eligibility.
    -- nil means the registry was unavailable on this evaluation.
    data.CreatineRegularity = nil
    data.CreatineExerciseCount = qualifiedCount

    for _, pack in ipairs(MilestoneSystem.Packs) do
        local achieved = data.CreatineLoaded == true
            and weight >= pack.weight
            and fitness >= pack.fitness
            and strength >= pack.strength
            and (regularityQualified or data.ActiveMilestones[pack.name] == true)
        if achieved then
            grantMilestone(player, data, pack.name)
        elseif removeMilestone(player, data, pack.name) then
            lostAny = true
        end
    end

    suppressWeightTraits(player, data)
    if lostAny then player:Say(MilestoneSystem.SpeechLoss) end
end

-- Keep day history in player ModData. Normalize legacy numeric keys to strings,
-- since current world-day keys are strings. Never replace a nonempty history.
local function normalizeDoseDays(data)
    local days = data.DoseDays
    local keysToMove = {}
    for key, taken in pairs(days) do
        if taken and type(key) == 'number' then
            keysToMove[#keysToMove + 1] = key
        end
    end
    for _, key in ipairs(keysToMove) do
        days[tostring(key)] = true
        days[key] = nil
    end
end

local function doseHistorySummary(data)
    local keys = {}
    for key, taken in pairs(data.DoseDays) do
        if taken then keys[#keys + 1] = tostring(key) end
    end
    table.sort(keys, function(a, b)
        return (tonumber(a) or math.huge) < (tonumber(b) or math.huge)
    end)
    return #keys, table.concat(keys, ',')
end

function C_Master_RecordDose(player)
    if not player or player:isDead() then return end
    local data = dataFor(player)
    local day = tostring(math.floor(getGameTime():getWorldAgeHours() / 24))
    local oldCount = tonumber(data.DoseDayCount)
    local oldLoaded = data.CreatineLoaded == true
    local beforeCount, beforeKeys = doseHistorySummary(data)

    normalizeDoseDays(data)
    local historyCount = doseHistorySummary(data)
    local playerName = tostring(player:getUsername())
    print('[CREATINE][server/SP][dose-before] player=' .. playerName ..
        ' worldDay=' .. day .. ' savedCount=' .. tostring(oldCount) ..
        ' historyCount=' .. tostring(beforeCount) .. ' days=[' .. beforeKeys ..
        '] loaded=' .. tostring(oldLoaded))

    -- The day-key set is canonical for known days. An older saved counter may
    -- represent days missing from that set; do not silently destroy that progress.
    -- A mismatch is explicitly logged so persistence loss can be diagnosed.
    local baseCount = historyCount
    if oldCount and oldCount > historyCount then
        baseCount = oldCount
        print('[CREATINE][server/SP][dose-warning] savedCount exceeds day history; ' ..
            'preserving legacy count, investigate missing keys: player=' .. playerName)
    end

    if not data.DoseDays[day] then
        data.DoseDays[day] = true
        data.DoseDayCount = baseCount + 1
        print('[CREATINE][server/SP] Dose recorded: player=' .. playerName ..
            ' worldDay=' .. day .. ' totalDays=' .. tostring(data.DoseDayCount))
        if player.Say then player:Say('Creatine dose recorded (' .. tostring(data.DoseDayCount) .. '/7 days).') end
    else
        data.DoseDayCount = baseCount
        print('[CREATINE][server/SP] Dose already recorded today: worldDay=' .. day)
    end

    if data.DoseDayCount >= MilestoneSystem.DAYS_TO_LOAD then
        data.CreatineLoaded = true
    end

    local afterCount, afterKeys = doseHistorySummary(data)
    print('[CREATINE][server/SP][dose-after] player=' .. playerName ..
        ' worldDay=' .. day .. ' savedCount=' .. tostring(data.DoseDayCount) ..
        ' historyCount=' .. tostring(afterCount) .. ' days=[' .. afterKeys ..
        '] loaded=' .. tostring(data.CreatineLoaded == true))
    C_Master_EvaluateMilestones(player)
end

local function evaluateAllPlayers()
    if isClient() then return end
    if isServer() then
        local players = getOnlinePlayers()
        for i = 0, players:size() - 1 do
            C_Master_EvaluateMilestones(players:get(i))
        end
    else
        local player = getPlayer()
        if player then C_Master_EvaluateMilestones(player) end
    end
end

Events.EveryOneMinute.Add(evaluateAllPlayers)

-- Multiplayer bridge. Only the server updates character modData or traits.
-- Item type is an allowlist hint, not proof of consumption. To make this
-- cheat-resistant, correlate with a server-observed consumption event later.
local CREATINE_allowedDoseTypes = {
    ["CREATINE.Creatine"] = true,
    ["CREATINE.CreatineSmoothie"] = true,
    ["JunkiezMoreSupplements.JunkiezShake"] = true,
    ["JunkiezMoreSupplements.JunkiezBlendedShake"] = true,
}

local function CREATINE_OnClientCommand(moduleName, commandName, player, args)
    if moduleName ~= 'CREATINE' or commandName ~= 'dose' then return end
    if not isServer() or not player or player:isDead() then return end
    if type(args) ~= 'table' or not CREATINE_allowedDoseTypes[args.itemType] then
        print('[CREATINE][server] Rejected malformed dose notification')
        return
    end
    print('[CREATINE][server] Received dose notification: ' .. tostring(args.itemType) .. ' from ' .. tostring(player:getUsername()))
    C_Master_RecordDose(player)
end

Events.OnClientCommand.Add(CREATINE_OnClientCommand)
