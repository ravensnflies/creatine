-- Rage behavior -- Project Zomboid 42.20 stable

local COOLDOWN_HOURS = 24 * 7
local TRIGGER_HEALTH = 20
local PROTECTION_TICKS = 30
local KILL_RADIUS = 3

local speech = {
    "RAGE!",
    "NOT YET!",
    "I WILL NOT DIE HERE!"
}

local function hasRage(player)
    return CREATINE_RageTraitType
        and player:hasTrait(CREATINE_RageTraitType)
end

local function killNearbyZombies(player)
    local cell = getCell()
    if not cell then return end

    local zombies = cell:getZombieList()
    local px = player:getX()
    local py = player:getY()
    local pz = player:getZ()
    local radiusSquared = KILL_RADIUS * KILL_RADIUS

    for i = 0, zombies:size() - 1 do
        local zombie = zombies:get(i)

        if zombie
                and not zombie:isDead()
                and zombie:getZ() == pz then

            local dx = zombie:getX() - px
            local dy = zombie:getY() - py

            if dx * dx + dy * dy <= radiusSquared then
                zombie:Kill(player)
            end
        end
    end
end

local function activate(player, cancelPendingHit)
    local data = player:getModData()
    local body = player:getBodyDamage()

    if cancelPendingHit then
        player:setAvoidDamage(true)
    end

    -- Completely restores health and clears bodily injuries.
    body:RestoreToFullHealth()

    if not player:isGodMod() then
        player:setGodMod(true)
        data.CREATINE_RageSetGodMode = true
    end

    data.CREATINE_RageProtectionTicks = PROTECTION_TICKS
    data.CREATINE_RageReadyAt =
        getGameTime():getWorldAgeHours() + COOLDOWN_HOURS

    killNearbyZombies(player)
    player:Say(speech[ZombRand(#speech) + 1])
end

local function onPlayerGetDamage(player, damageType, damageAmount)
    if isClient()
            or not player
            or player:isDead()
            or not hasRage(player) then
        return
    end

    local data = player:getModData()
    local currentHour = getGameTime():getWorldAgeHours()

    if currentHour < (data.CREATINE_RageReadyAt or 0) then
        return
    end

    local health = player:getBodyDamage():getOverallBodyHealth()
    local damage = tonumber(damageAmount) or 0
    local projectedHealth = health - damage
    local cancelPendingHit = damageType == "WEAPONHIT"

    if health <= TRIGGER_HEALTH
            or projectedHealth <= TRIGGER_HEALTH then
        activate(player, cancelPendingHit)
    end
end

local function onPlayerUpdate(player)
    if isClient() or not player then return end

    local data = player:getModData()
    local ticks = data.CREATINE_RageProtectionTicks

    if ticks then
        ticks = ticks - 1

        if ticks <= 0 then
            if data.CREATINE_RageSetGodMode then
                player:setGodMod(false)
            end

            data.CREATINE_RageSetGodMode = nil
            data.CREATINE_RageProtectionTicks = nil
        else
            data.CREATINE_RageProtectionTicks = ticks
        end
    end

    -- Catch gradual damage that may be applied before its event is processed.
    if player:isDead() or not hasRage(player) then
        return
    end

    local currentHour = getGameTime():getWorldAgeHours()

    if currentHour < (data.CREATINE_RageReadyAt or 0) then
        return
    end

    if player:getBodyDamage():getOverallBodyHealth()
            <= TRIGGER_HEALTH then
        activate(player, false)
    end
end

Events.OnPlayerGetDamage.Add(onPlayerGetDamage)
Events.OnPlayerUpdate.Add(onPlayerUpdate)